<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jeniskuliner extends CI_Controller {

    public function index()
	{
		$this->load->model('jeniskuliner_model','jk');
        $data['list_jk']=$this->jk->getAll();

        $this->load->view('header');
        $this->load->view('jenis_kuliner/index',$data);
        $this->load->view('footer');

        //$this->load->view('tamplate');
	}
    public function create()
    {
        $data['']='';
        $this->load->view('header');
        $this->load->view('jenis_kuliner/form',$data);
        $this->load->view('footer');
    }
    public function save()
    {
        $this->load->model('jeniskuliner_model','jk');

        $nama = $this->input->post('nama');
        $idedit = $this->input->post('idedit');

        $data_jk['nama']=$nama;// ?1
        
        if(!empty($idedit)){//update
            $data_jk['id']=$idedit;//?2

            $this->jk->update($data_jk);
        }else{//tambah data baru
            $this->jk->simpan($data_jk);
        }
        redirect('jeniskuliner','refresh');
        
        // /* $data['list_dosen']=$this->dosen->getAll();
        // $this->load->view('header');
        // $this->load->view('jenis_kuliner/index',$data);
        // $this->load->view('footer'); 
    }


    public function edit($id){
        $this->load->model('jeniskuliner_model','jk');
        $obj_jk = $this->jk->findById($id);
        $data['objjk']=$obj_jk;


        $this->load->view('header');
        $this->load->view('jenis_kuliner/edit',$data);
        $this->load->view('footer');
    }

    public function delete($id){

        $this->load->model('jeniskuliner_model','jk');
        $data_jk['id']=$id;
        //pastikan role diperkenankan
        $this->jk->delete($data_jk);
        redirect('jeniskuliner','refresh');
    }
}
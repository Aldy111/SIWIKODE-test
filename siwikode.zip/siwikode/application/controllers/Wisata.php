<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wisata extends CI_Controller {

    public function index()
	{
		$this->load->model('wisata_model','wisata');
        $data['list_wisata']=$this->wisata->getAll();
        
        $this->load->view('header');
        $this->load->view('wisata/index',$data);
        $this->load->view('footer');

        //$this->load->view('tamplate');
	}
    public function detail($id)
    {
        
        $this->load->model('wisata_model','wisata'); //load model
        $data['list_wisata'] = $this->wisata->findById($id);
    
        $this->load->view('header.php');
        $this->load->view('wisata/detail', $data);
        $this->load->view('footer.php');
    }

    public function create()
    {
        $data['']='';
        $this->load->view('header');
        $this->load->view('wisata/form',$data);
        $this->load->view('footer');
    }
}
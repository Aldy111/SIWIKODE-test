<?php
class Wisata_model extends CI_Model{

    public function getAll(){
        //SELECT * FROM wisata;
        $query = $this->db->get('wisata');
        return $query;
    }

    public function findById($id){
        //SELECT * FROM jenis_wisata WHERE id=1;
        $query = $this->db->get_where('wisata', array('id' => $id));
        return $query->row();
    }


}
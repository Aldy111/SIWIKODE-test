<?php
class Jeniswisata_model extends CI_Model{

    public function getAll(){
        //SELECT * FROM jenis_wisata;
        $query = $this->db->get('jenis_wisata');
        return $query;
    }

    //mengambil data jenis_wisata yang memiliki $id tertentu
    public function findById($id){
        //SELECT * FROM jenis_wisata WHERE id=1;
        $query = $this->db->get_where('jenis_wisata', array('id' => $id));
        return $query->row();
    }

    public function simpan($data)
    {
        // INSERT INTO jenis_wisata (nama) VALUES ('budi');
        $sql = "INSERT INTO jenis_wisata (nama) VALUES (?)";
        //$this->db->query($sql, array('111','budi'));
        $this->db->query($sql,$data);
    }

    public function update($data){
        //UPDATE dosen SET nidn='1111',nama='aldy prayogo s.kom' WHERE id=1;
        $sql = "UPDATE jenis_wisata SET nama=? WHERE id=?";
        $this->db->query($sql, $data);
    }

    public function delete($data){
        //DELETE FROM dosen WHERE id=1;
        $sql = "DELETE FROM jenis_wisata WHERE id=?";
        $this->db->query($sql, $data);
    }

}
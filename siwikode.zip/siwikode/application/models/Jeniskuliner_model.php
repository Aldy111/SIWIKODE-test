<?php
class Jeniskuliner_model extends CI_Model{

    public function getAll(){
        //SELECT * FROM jenis_kuliner;
        $query = $this->db->get('jenis_kuliner');
        return $query;
    }

    //mengambil data jenis_kuliner yang memiliki $id tertentu
    public function findById($id){
        //SELECT * FROM jenis_kuliner WHERE id=1;
        $query = $this->db->get_where('jenis_kuliner', array('id' => $id));
        return $query->row();
    }

    public function simpan($data)
    {
        // INSERT INTO dosen (nidn,nama) VALUES ('111','budi');
        $sql = "INSERT INTO jenis_kuliner (nama) VALUES (?)";
        //$this->db->query($sql, array('111','budi'));
        $this->db->query($sql,$data);
    }

    public function update($data){
        //UPDATE dosen SET nidn='1111',nama='aldy prayogo s.kom' WHERE id=1;
        $sql = "UPDATE jenis_kuliner SET nama=? WHERE id=?";
        $this->db->query($sql, $data);
    }

    public function delete($data){
        //DELETE FROM dosen WHERE id=1;
        $sql = "DELETE FROM jenis_kuliner WHERE id=?";
        $this->db->query($sql, $data);
    }

}
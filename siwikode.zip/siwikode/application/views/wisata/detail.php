

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h1 class="m-0 font-weight-bold text-primary">Detail Wisata </h1>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">
                                    <tbody>
                                        <tr>
                                            <td>Nama</td> <td>:</td>
                                            <td><?=$list_wisata->nama?></td>
                                        </tr>

                                        <tr>
                                            <td>Deskripsi</td> <td>:</td>
                                            <td><?=$list_wisata->deskripsi?></td>
                                        </tr>

                                        <tr>
                                            <td>Jenis Wisata</td> <td>:</td>
                                            <td><?=$list_wisata->jenis_wisata_id?></td>
                                        </tr>

                                        <tr>
                                            <td>Fasilitas</td> <td>:</td>
                                            <td><?=$list_wisata->fasilitas?></td>
                                        </tr>

                                        <tr>
                                            <td>Bintang</td> <td>:</td>
                                            <td><?=$list_wisata->bintang?></td>
                                        </tr>

                                        <tr>
                                            <td>Kontak</td> <td>:</td>
                                            <td><?=$list_wisata->kontak?></td>
                                        </tr>

                                        <tr>
                                            <td>Alamat</td> <td>:</td>
                                            <td><?=$list_wisata->alamat?></td>
                                        </tr>

                                        <tr>
                                            <td>Latlong</td> <td>:</td>
                                            <td><?=$list_wisata->latlong?></td>
                                        </tr>

                                        <tr>
                                            <td>Email</td> <td>:</td>
                                            <td><?=$list_wisata->email?></td>
                                        </tr>

                                        <tr>
                                            <td>Web</td> <td>:</td>
                                            <td><?=$list_wisata->web?></td>
                                        </tr>

                                        <tr>
                                            <td>Jenis Kuliner</td> <td>:</td>
                                            <td><?=$list_wisata->jenis_kuliner_id?></td>
                                        </tr>
                                        
                            </div>
                                    </tbody>
                                </table>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

          
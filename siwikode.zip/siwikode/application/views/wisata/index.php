<script>
    function hapusWisata(pesan)  {
        if(confirm(pesan)){
            return true;
        }else{
            return false;
        }
    }
</script>
    <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h1 class="m-0 font-weight-bold text-success">Daftar Wisata</h1>
                            <a href="<?=base_url()?>index.php/wisata/create" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Tambah Data</a></br>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Wisata</th>
                                            <th>Deskripsi</th>
                                            <th>fasilitas</th>
                                            <th>Bintang</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                
                                    <tbody>
                                    <?php
                                    $nomor = 1;
                                    foreach ($list_wisata->result() as $row) 
                                    
                                    {
                                        
                                        echo '<tr><td>'.$nomor.'</td>';
                                        echo '<td>'.$row->nama.'</td>';
                                        echo '<td>'.$row->deskripsi.'</td>';
                                        echo '<td>'.$row->fasilitas.'</td>';
                                        echo '<td>'.$row->bintang.'</td>';
                                        
                                        //echo '<td>view | edit | delete</td>';
                                        echo '<td>
                                    
                                        <a href="'.base_url().'index.php/wisata/edit/'.$row->id.'" class="btn btn-warning btn-lg active" role="button" aria-pressed="true">Edit</a>
                                        <a href="'.base_url().'index.php/wisata/delete/'.$row->id.'" class="btn btn-danger btn-lg active" role="button" aria-pressed="true"onclick="return hapusWisata(\'Data Profesi '.$row->nama.' Yakin mau dihapus ??\')">Delete</a>
                                        <a href="'.base_url().'index.php/wisata/detail/'.$row->id.'" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Detail</a>
                                        </td>';
                                        echo '</tr>';
                                    
                                        $nomor++;
                                    }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->




<h1>Form Jenis Kuliner</h1>
<?php echo form_open('jeniskuliner/save');?>
  <div class="form-group row">
    <label for="nama" class="col-4 col-form-label">Nama jenis kuliner</label> 
    <div class="col-8">
      <input id="nama" name="nama" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
  <?php echo form_close()?>

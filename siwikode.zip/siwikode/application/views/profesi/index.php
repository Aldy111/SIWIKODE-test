<script>
    function hapusWisata(pesan)  {
        if(confirm(pesan)){
            return true;
        }else{
            return false;
        }
    }
</script>
<h1>Daftar Profesi</h1>
<a href="<?=base_url()?>index.php/profesi/create" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Tambah Data</a></br></br>
<table class="table">
<thead>
    <tr>
        <th>No</th><th>Nama Profesi</th><th>Action</th>
    </tr>
</thead>
<tbody>
<?php
$nomor = 1;
foreach ($list_profesi->result() as $row) 

{
    
    echo '<tr><td>'.$nomor.'</td>';
    echo '<td>'.$row->nama.'</td>';
    //echo '<td>view | edit | delete</td>';
    echo '<td>

    <a href="'.base_url().'index.php/profesi/edit/'.$row->id.'" class="btn btn-warning btn-lg active" role="button" aria-pressed="true">Edit</a>
    <a href="'.base_url().'index.php/profesi/delete/'.$row->id.'" class="btn btn-danger btn-lg active" role="button" aria-pressed="true"onclick="return hapusWisata(\'Data Jenis Wisata '.$row->nama.' Yakin mau dihapus ??\')">Delete</a>
    </td>';
    echo '</tr>';

    $nomor++;

}


?>
</tbody>
</table>